# Face-Recognition-Web-App
A face recognition model built using Open CV and finally deployed on webpage using Streamlit. Full video explanation at : 
